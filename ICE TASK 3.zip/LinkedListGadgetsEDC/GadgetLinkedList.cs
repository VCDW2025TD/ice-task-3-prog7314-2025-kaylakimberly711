using System;

public class GadgetLinkedList
{
    private GadgetNode? head;

    public int Count { get; private set; }

    public void AddLast(Gadget gadget)
    {
        var newNode = new GadgetNode(gadget);
        if (head == null)
        {
            head = newNode;
        }
        else
        {
            var current = head;
            while (current.Next != null)
                current = current.Next;
            current.Next = newNode;
        }
        Count++;
    }

    public void AddFirst(Gadget gadget)
    {
        var newNode = new GadgetNode(gadget);
        newNode.Next = head;
        head = newNode;
        Count++;
    }

    public void InsertAt(int index, Gadget gadget)
    {
        if (index < 0 || index > Count)
            throw new ArgumentOutOfRangeException("Invalid index");

        if (index == 0)
        {
            AddFirst(gadget);
            return;
        }

        var newNode = new GadgetNode(gadget);
        var current = head;

        for (int i = 0; i < index - 1; i++)
            current = current!.Next;

        newNode.Next = current!.Next;
        current.Next = newNode;
        Count++;
    }

    public bool Remove(string name)
    {
        if (head == null) return false;

        if (head.Data.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
        {
            head = head.Next;
            Count--;
            return true;
        }

        var current = head;
        while (current.Next != null && !current.Next.Data.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
            current = current.Next;

        if (current.Next == null) return false;

        current.Next = current.Next.Next;
        Count--;
        return true;
    }

    public bool RemoveFirst()
    {
        if (head == null) return false;
        head = head.Next;
        Count--;
        return true;
    }

    public bool RemoveLast()
    {
        if (head == null) return false;

        if (head.Next == null)
        {
            head = null;
            Count--;
            return true;
        }

        var current = head;
        while (current.Next?.Next != null)
            current = current.Next;

        current.Next = null;
        Count--;
        return true;
    }

    public bool Contains(string name)
    {
        var current = head;
        while (current != null)
        {
            if (current.Data.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                return true;
            current = current.Next;
        }
        return false;
    }

    public Gadget? Find(string name)
    {
        var current = head;
        while (current != null)
        {
            if (current.Data.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                return current.Data;
            current = current.Next;
        }
        return null;
    }

    public void Reverse()
    {
        GadgetNode? prev = null;
        var current = head;

        while (current != null)
        {
            var next = current.Next;
            current.Next = prev;
            prev = current;
            current = next;
        }

        head = prev;
    }

    public void Clear()
    {
        head = null;
        Count = 0;
    }

    public void DisplayAll()
    {
        var current = head;
        while (current != null)
        {
            Console.WriteLine(current.Data);
            current = current.Next;
        }
    }

    public void DisplayByDay(DayOfWeek day)
    {
        var current = head;
        while (current != null)
        {
            if (current.Data.IsCarriedOn(day))
                Console.WriteLine(current.Data);
            current = current.Next;
        }
    }
}
