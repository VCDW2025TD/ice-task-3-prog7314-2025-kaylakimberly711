public class GadgetNode
{
    public Gadget Data { get; set; }
    public GadgetNode? Next { get; set; }  // ← nullable

    public GadgetNode(Gadget data)
    {
        Data = data;
        Next = null;
    }
}
