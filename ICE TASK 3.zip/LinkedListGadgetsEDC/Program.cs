﻿using System;
using System.Collections.Generic;


class Program
{
    static GadgetLinkedList edcList = new GadgetLinkedList();

    static void Main(string[] args)
    {
        //var edcList = new GadgetLinkedList();
        Seed(edcList);

        while (true)
        {
            WriteHeader("\n=== EDC Gadget Manager (LinkedList) ===");
            WriteMuted("1) AddLast");
            WriteMuted("2) AddFirst");
            WriteMuted("3) InsertAt");
            WriteMuted("4) Remove (by name)");
            WriteMuted("5) RemoveFirst");
            WriteMuted("6) RemoveLast");
            WriteMuted("7) Find (by name)");
            WriteMuted("8) Display All");
            WriteMuted("9) Display By Day");
            WriteMuted("10) Reverse");
            WriteMuted("11) Clear");
            WriteMuted("12) Count");
            WriteMuted("0) Exit");
            Console.Write("\nChoose an option: ");

            var choice = Console.ReadLine()?.Trim();
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    edcList.AddLast(ReadGadgetFromUser());
                    WriteSuccess("Added to end.");
                    break;

                case "2":
                    edcList.AddFirst(ReadGadgetFromUser());
                    WriteSuccess("Added to start.");
                    break;

                case "3":
                    if (edcList.Count == 0)
                    {
                        WriteWarn("List is empty. Use AddFirst/AddLast instead.");
                        break;
                    }
                    int index = ReadInt("Index (0-based): ", 0, edcList.Count);
                    edcList.InsertAt(index, ReadGadgetFromUser());
                    WriteSuccess($"Inserted at index {index}.");
                    break;

                case "4":
                    Console.Write("Enter name to remove: ");
                    var removeName = Console.ReadLine() ?? string.Empty;
                    (edcList.Remove(removeName) ? (Action<string>)WriteSuccess : WriteWarn)
                        ($"'{removeName}' " + (edcList.Contains(removeName) ? "still present?" : "removed (if present)."));
                    break;

                case "5":
                    (edcList.RemoveFirst() ? (Action<string>)WriteSuccess : WriteWarn)("Removed first (if any).");
                    break;

                case "6":
                    (edcList.RemoveLast() ? (Action<string>)WriteSuccess : WriteWarn)("Removed last (if any).");
                    break;

                case "7":
                    Console.Write("Enter name to find: ");
                    var findName = Console.ReadLine() ?? string.Empty;
                    var found = edcList.Find(findName);
                    if (found != null) { WriteSuccess("Found:"); Console.WriteLine(found); }
                    else WriteWarn("Not found.");
                    break;

                case "8":
                    WriteHeader("All gadgets:");
                    if (edcList.Count == 0) WriteWarn("(empty)");
                    else edcList.DisplayAll();
                    break;

                case "9":
                    var day = ReadDayOfWeek();
                    WriteHeader($"Gadgets for {day}:");
                    edcList.DisplayByDay(day);
                    break;

                case "10":
                    edcList.Reverse();
                    WriteSuccess("List reversed.");
                    break;

                case "11":
                    edcList.Clear();
                    WriteSuccess("List cleared.");
                    break;

                case "12":
                    WriteInfo($"Count: {edcList.Count}");
                    break;

                case "0":
                    WriteInfo("Bye!");
                    return;

                default:
                    WriteError("Invalid choice. Try again.");
                    break;
            }
        }
    }

    // --- Helpers ---

    static void Seed(GadgetLinkedList list)
    {
        list.AddLast(new Gadget("Wallet", EveryDay()));
        list.AddLast(new Gadget("Laptop", Weekdays()));
        list.AddLast(new Gadget("Gym Bag", new List<DayOfWeek> { DayOfWeek.Monday, DayOfWeek.Thursday }));
    }

static Gadget ReadGadgetFromUser()
{
    string name;
    while (true)
    {
        Console.Write("Gadget name: ");
        name = (Console.ReadLine() ?? "").Trim();

        if (string.IsNullOrWhiteSpace(name))
        {
            WriteError("Name cannot be empty. Please try again.");
            continue;
        }

        if (edcList.Contains(name))
        {
            WriteWarn($"A gadget named '{name}' already exists. Please use a different name.");
            continue;
        }

        break;
    }

    var days = ReadDaysFromUser();
    return new Gadget(name, days);
}


    static List<DayOfWeek> ReadDaysFromUser()
    {
        WriteMuted("Enter days carried (comma-separated), or type:");
        WriteMuted(" - 'everyday' | 'weekdays' | 'weekends'");
        WriteMuted("You can also enter numbers 0-6 (Sunday=0 ... Saturday=6) or names (Mon, Tuesday, etc.)");
        Console.Write("Days: ");

        var input = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(input)) return new List<DayOfWeek>();

        if (input == "everyday") return EveryDay();
        if (input == "weekdays") return Weekdays();
        if (input == "weekends") return Weekends();

        var parts = input.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        var result = new List<DayOfWeek>();

        foreach (var p in parts)
        {
            if (int.TryParse(p, out int num) && num >= 0 && num <= 6)
            {
                result.Add((DayOfWeek)num); // Sunday=0 ... Saturday=6
                continue;
            }

            if (TryParseDay(p, out var day))
            {
                result.Add(day);
                continue;
            }

            WriteWarn($"Skipped unrecognized day: '{p}'");
        }

        return result;
    }

    static bool TryParseDay(string token, out DayOfWeek day)
    {
        token = token.Trim().ToLowerInvariant();
        switch (token)
        {
            case "sun": token = "sunday"; break;
            case "mon": token = "monday"; break;
            case "tue":
            case "tues": token = "tuesday"; break;
            case "wed": token = "wednesday"; break;
            case "thu":
            case "thur":
            case "thurs": token = "thursday"; break;
            case "fri": token = "friday"; break;
            case "sat": token = "saturday"; break;
        }
        if (Enum.TryParse(typeof(DayOfWeek), token, true, out var parsed))
        {
            day = (DayOfWeek)parsed!;
            return true;
        }
        day = default;
        return false;
    }

    static DayOfWeek ReadDayOfWeek()
    {
        WriteMuted("Pick a day:");
        WriteMuted("0) Sunday");
        WriteMuted("1) Monday");
        WriteMuted("2) Tuesday");
        WriteMuted("3) Wednesday");
        WriteMuted("4) Thursday");
        WriteMuted("5) Friday");
        WriteMuted("6) Saturday");
        int n = ReadInt("Choose 0-6: ", 0, 6);
        return (DayOfWeek)n;
    }

    static int ReadInt(string prompt, int min, int max)
    {
        while (true)
        {
            Console.Write(prompt);
            var s = Console.ReadLine();
            if (int.TryParse(s, out int n) && n >= min && n <= max)
                return n;
            WriteError($"Please enter a number between {min} and {max}.");
        }
    }

    static List<DayOfWeek> EveryDay() =>
        new List<DayOfWeek> {
            DayOfWeek.Sunday, DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday,
            DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday
        };

    static List<DayOfWeek> Weekdays() =>
        new List<DayOfWeek> {
            DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday
        };

    static List<DayOfWeek> Weekends() =>
        new List<DayOfWeek> {
            DayOfWeek.Saturday, DayOfWeek.Sunday
        };

    // --- FOr better printing ---

    static void WithColor(ConsoleColor color, Action write)
    {
        var prev = Console.ForegroundColor;
        Console.ForegroundColor = color;
        write();
        Console.ForegroundColor = prev;
    }

    static void WriteHeader(string text) => WithColor(ConsoleColor.Cyan, () => Console.WriteLine(text));
    static void WriteSuccess(string text) => WithColor(ConsoleColor.Green, () => Console.WriteLine(text));
    static void WriteWarn(string text) => WithColor(ConsoleColor.Yellow, () => Console.WriteLine(text));
    static void WriteError(string text) => WithColor(ConsoleColor.Red, () => Console.WriteLine(text));
    static void WriteInfo(string text) => WithColor(ConsoleColor.White, () => Console.WriteLine(text));
    static void WriteMuted(string text) => WithColor(ConsoleColor.DarkGray, () => Console.WriteLine(text));
}