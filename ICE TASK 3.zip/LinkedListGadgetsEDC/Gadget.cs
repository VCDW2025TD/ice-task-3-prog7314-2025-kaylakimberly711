using System;
using System.Collections.Generic;

public class Gadget
{
    public string Name { get; set; }
    public List<DayOfWeek> DaysToCarry { get; set; }

    public Gadget(string name, List<DayOfWeek> daysToCarry)
    {
        Name = name;
        DaysToCarry = daysToCarry;
    }

    public bool IsCarriedOn(DayOfWeek day)
    {
        return DaysToCarry.Contains(day);
    }

    public override string ToString()
    {
        string days = string.Join(", ", DaysToCarry);
        return $"{Name} (Carried on: {days})";
    }
}
